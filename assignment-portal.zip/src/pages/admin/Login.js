import { FormAdminLogin } from "../../components/admin_components/form_admin_login";

function AdminLogin() {
    return (
        <>
            <FormAdminLogin />
        </>
    );
}

export default AdminLogin;