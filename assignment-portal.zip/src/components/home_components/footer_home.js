import {
    Box,
    Container,
    Stack,
    Text,
    useColorModeValue,
} from '@chakra-ui/react';
import facebook from '../../assets/foter/facebook.png'
import insta from '../../assets/foter/insta.png'
import pinterest from '../../assets/foter/pinterest.png'
import twitter from '../../assets/foter/twitter.png'
import youtube from '../../assets/foter/youtube.png'
import payment from '../../assets/payment.png'
export function FooterHome() {
    return (
        <div className='row p-0 m-0  set-back'>
            <div className='col-12 '>

                <div className="row pt-4 m-0  d-flex align-items-center">
                    <div className="col-md-6 col-12">
                        <div className="social d-flex align-items-center ml-4">
                            <img src={facebook} />
                            <img src={insta} />
                            <img src={pinterest} />
                            <img src={twitter} />
                            <img src={youtube} />
                        </div>

                    </div>
                    <div className="col-md-6 col-12">
                        <div className="payment d-flex flex-column flex-lg-row flex-sm-column align-items-center justify-content-around">
                            <div className='set_'>100% Secure Payment </div>
                            <img src={payment} alt="" />
                        </div>
                    </div>
                </div>

                {/* <div className="first_footer"> */}

                <p className='set_text_footer text-white p-4 text-center'><b>Disclaimer:</b> The reference papers provided by Assignment Santa should be used as model papers only. Students are not to copy or submit them as is. These reference papers are strictly intended for research and reference purposes only.</p>
                {/* </div> */}

<hr />

                {/* <div className="second_footer"> */}
                <div className="row second-fo">
                    <div className="col p-3">

                        © 2022 Assignment Santa. All rights reserved
                    </div>

                    {/* </div> */}
                </div>

            </div>
        </div>
    );
}