import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import CountUp from 'react-countup';
import { HiOutlineClipboardList } from 'react-icons/hi';
import { useCountUp } from 'react-countup';
export default function Counter() {

    const [counter, setCounter] = useState(0);
    // useEffect(() => {
    //     // if(counter <= 1000){
    //         setTimeout(() => {
    //             setcounter((counter)=> counter + 1)
    //         },100);

    //     // }
    // }, [counter])

    // useEffect(() => {
    //     counterFun()

    // }, [0]);
    // const counterFun=()=>{

    //     setInterval(() => {
    //         if(counter <= 1){
    //             setCounter((counter) => counter + 1);

    //         }else if (counter == 1000){
    //             setCounter(3000);

    //         }
    //     }, 1);

    // }

    const countUpRef = React.useRef(null);
    const { start } = useCountUp({
        ref: countUpRef,
        start: 0,
        end: 324987,
        // delay: 1000,
        duration: 3,
    });
    const firstCount = () => {
        // console.log(window.scrollY);
        if (window.scrollY >= 500) {
            // start()
        } else {
            console.log('false')

        }
    }
    // const secondCount = () => {
    //     console.log(window.scrollY);
    //     if (window.scrollY >= 500) {
    //         start()
    //     } else {
    //         console.log('false')

    //     }
    // }
    useEffect(() => {
        start()
    }, [])
    
    window.addEventListener('scroll', firstCount )

    return (
        <>
            <div className="Mycont m-0">
                <div className="row p-0 m-0">
                    <div className="col-12 headings1 my-4 d-flex justify-content-center align-items-center">
                        <HiOutlineClipboardList className='mt-0 mr-2 Fs' /><h2> Assignment Santa</h2>
                    </div>
                    <div className='col-12 d-flex justify-content-center client_heading'>
                        Take help from best MBA writing service in Australia
                    </div>
                </div>
                <br />
                <br />
                <div className="row p-0 m-0">
                    <div className="col-md-4 col-12">
                        <div className='boxx'>
                            <div className='counter_'>

                                <>
                                    <div className="d-flex flex-column justify-content-center ">

                                        <div className='d-flex justify-content-center'>

                                            <span ref={countUpRef} />+
                                        </div>
                                        <div className='Fs-3'>
                                            Assignments
                                        </div>
                                    </div>
                                </>

                                {/* <CountUp
                                    start={0}
                                    end={100}
                                    duration={3.75}
                                    separator=" "
                                    delay={1}
                                    // decimals={4}
                                    // decimal=","
                                    // prefix="EUR "
                                    // suffix=" left"
                                    onEnd={() => console.log('Ended! 👏')}
                                    onStart={() => console.log('Started! 💨')}
                                >
                                    {({ countUpRef, start }) => (
                                        <div>
                                            <span ref={countUpRef} />
                                            <button onClick={start}>Start</button>
                                        </div>
                                    )}
                                </CountUp> */}
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-12">
                        <div className='counter_'>
                            <CountUp start={0} end={2014} delay={0}>
                                {({ countUpRef }) => (
                                    <>
                                        <div className="d-flex flex-column justify-content-center ">

                                            <div className='d-flex justify-content-center'>


                                                <span ref={countUpRef} />+
                                            </div>
                                            <div className='Fs-3'>
                                                PHD Experts
                                            </div>
                                        </div>
                                    </>
                                )}
                            </CountUp>
                        </div>
                    </div>
                    <div className="col-md-4 col-12">
                        <div className='counter_'>
                            <CountUp start={0} end={157} delay={0}>

                                {({ countUpRef }) => (
                                    <>
                                        <div className="d-flex flex-column justify-content-center ">

                                            <div className='d-flex justify-content-center'>
                                                <span ref={countUpRef} />+
                                            </div>
                                            <div className='Fs-3'>
                                                Subjects
                                            </div>
                                        </div>
                                    </>
                                )}
                            </CountUp>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}
