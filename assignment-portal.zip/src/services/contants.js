export const apiUrl = "https://assignment-santa-api.azurewebsites.net";
export const chatUrl = 'https://assignment-santa-communication.communication.azure.com/';